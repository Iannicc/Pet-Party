package testDominio;

import static org.junit.Assert.*;

import java.sql.Blob;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.junit.*;

import dominio.Animale;
import dominio.Commento;
import dominio.Like;
import dominio.Post;
import dominio.PostAnimale;
import dominio.ProPost;

public class TestPost 
{
	private Date dataCreazione;
	private Blob media;
	private List<Commento> commenti;
	private Set<Like>likes;
	private Set <Animale> animali;
	ProPost p;
	PostAnimale pa;
	
	@Before
	public void setup() throws SQLException
	{
		dataCreazione= new Date(0);
		commenti= new ArrayList<Commento>();
		likes = new TreeSet<Like>();
		animali = new TreeSet<Animale>();
		p = new ProPost(dataCreazione, media, "gran bel proPost", commenti,likes );
		pa= new PostAnimale(dataCreazione, media, "gran bel postAnimali", commenti,likes,animali);
	}
	
	@Test
	public void TestGetterPost()
	{
		assertEquals(p.getCommenti(),commenti);
		assertEquals(p.getDataCreazione(),dataCreazione);
		assertEquals(p.getDescrizione(),"gran bel proPost");
		assertEquals(p.getLikes(),likes);
		assertEquals(p.getMedia(),media);
		
		assertEquals(pa.getCommenti(),commenti);
		assertEquals(pa.getDataCreazione(),dataCreazione);
		assertEquals(pa.getDescrizione(),"gran bel postAnimali");
		assertEquals(pa.getLikes(),likes);
		assertEquals(pa.getMedia(),media);
		assertEquals(pa.getAnimali(),animali);
		
	}
	

	@Test
	public void TestSetterPost()
	{
		p= new ProPost();
		pa=new PostAnimale();
		p.setCommenti(commenti);
		p.setDataCreazione(dataCreazione);
		p.setDescrizione("gran bel proPost");
		p.setLikes(likes);
		p.setMedia(media);
		pa.setCommenti(commenti);
		pa.setDataCreazione(dataCreazione);
		pa.setDescrizione("gran bel proPost");
		pa.setLikes(likes);
		pa.setMedia(media);
		pa.setAnimali(animali);
		
		assertEquals(p.getCommenti(),commenti);
		assertEquals(p.getDataCreazione(),dataCreazione);
		assertEquals(p.getDescrizione(),"gran bel proPost");
		assertEquals(p.getLikes(),likes);
		assertEquals(p.getMedia(),media);
		
		assertEquals(pa.getCommenti(),commenti);
		assertEquals(pa.getDataCreazione(),dataCreazione);
		assertEquals(pa.getDescrizione(),"gran bel postAnimali");
		assertEquals(pa.getLikes(),likes);
		assertEquals(pa.getMedia(),media);
		assertEquals(pa.getAnimali(),animali);
	}
}
