package testDominio;

import static org.junit.Assert.assertEquals;

import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.rowset.serial.SerialBlob;

import org.junit.Before;
import org.junit.Test;

import dominio.Animale;
import dominio.PostAnimale;
import dominio.Sesso;

public class TestAnimale 
{
	private String razza;
	private String specie;
	private Sesso sex;
	byte[] stream;
	Blob immagine;
	private List<PostAnimale> posts=new ArrayList<PostAnimale>();
	Animale a;
	
	@Before
	public void setup() throws SQLException
	{
		stream=new byte[7];
		immagine = new SerialBlob(stream);
		a=new Animale("Lugia", "ma quanto è forte?",immagine, "uccello","leggendario",Sesso.Maschio,posts);
		
	}
	
	@Test
	public void TestGetterUtenteStandard()
	{
		assertEquals(a.getDescrizione(),"ma quanto è forte?");
		assertEquals(a.getImage(),immagine);
		assertEquals(a.getNome(),"Lugia");
		assertEquals(a.getPosts(),posts);
		assertEquals(a.getRazza(),"uccello");
		assertEquals(a.getSex(),Sesso.Maschio);
		assertEquals(a.getSpecie(),"leggendario");
		
	}
	
	@Test
	public void TestSetterUtenteStandard()
	{
		a=new Animale();
		a.setDescrizione("ma quanto è forte?");
		a.setImage(immagine);
		a.setNome("Lugia");
		a.setPosts(posts);
		a.setRazza("uccello");
		a.setSex(Sesso.Femmina);
		a.setSpecie("leggendario");
		assertEquals(a.getDescrizione(),"ma quanto è forte?");
		assertEquals(a.getImage(),immagine);
		assertEquals(a.getNome(),"Lugia");
		assertEquals(a.getPosts(),posts);
		assertEquals(a.getRazza(),"uccello");
		assertEquals(a.getSex(),Sesso.Femmina);
		assertEquals(a.getSpecie(),"leggendario");
	}
	
}
