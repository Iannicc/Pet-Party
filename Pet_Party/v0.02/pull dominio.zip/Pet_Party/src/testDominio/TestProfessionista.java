package testDominio;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.rowset.serial.SerialBlob;

import org.junit.Before;
import org.junit.Test;

import dominio.Animale;
import dominio.ProPost;
import dominio.Professionista;
import dominio.ProfiloProfessionista;
import dominio.UtenteStandard;

public class TestProfessionista 
{
	private Professionista pro;
	private ProfiloProfessionista p;
	byte[] stream;
	Blob immagine;
	List<Animale>as;
	List<UtenteStandard>followers;
	List<UtenteStandard>followed;
	List<ProPost> proposts;
	@Before
	public void setup() throws SQLException
	{
		stream=new byte[7];
		immagine = new SerialBlob(stream);
		as=new ArrayList<Animale>();
		followers=new ArrayList<UtenteStandard>();
		followed=new ArrayList<UtenteStandard>();
		proposts = new ArrayList<ProPost>();
		p=new ProfiloProfessionista("Carlo","gran veterinario, forte proprio",immagine,"crociani","Bologna","3420476687",as,proposts);
		pro=new Professionista("vet1",p,false,"veterinario","felini",true,followers,followed);
	}
	
	@Test
	public void TestGetterProfessionista()
	{
		assertEquals(pro.getProfilo(),p);
		assertEquals(pro.getUsername(),"vet1");
		assertFalse(pro.isBloccato());
		assertFalse(pro.isAbilitato());
		assertEquals(pro.getProfessione(),"veterinario");
		assertEquals(pro.getSpecializzazione(),"felini");
		assertEquals(pro.getFollowers(),followers);
		assertEquals(pro.getFollowed(),followed);
		
	}

	@Test
	public void TestSetterProfessionista()
	{
		pro=new Professionista();
		ProfiloProfessionista profilo =new ProfiloProfessionista("Carlo","gran veterinario, forte proprio",immagine,"crociani","Bologna","3420476687",as,proposts);
		pro.setProfilo(profilo);
		assertEquals(pro.getProfilo(),profilo);
		pro.setUsername("vet1");
		assertEquals(pro.getUsername(),"vet1");
		pro.setBloccato(true);
		assertTrue(pro.isBloccato());
		pro.setAbilitato(true);
		assertTrue(pro.isAbilitato());
		pro.setProfessione("veterinario");
		assertEquals(pro.getProfessione(),"veterinario");
		pro.setSpecializzazione("felini");
		assertEquals(pro.getSpecializzazione(),"felini");
		pro.setFollowers(followers);
		pro.setFollowed(followed);
		assertEquals(pro.getFollowers(),followers);
		assertEquals(pro.getFollowed(),followed);
	}

}
