package testDominio;

import static org.junit.Assert.*;

import java.sql.*;
import java.util.*;

import javax.sql.rowset.serial.SerialBlob;

import org.junit.*;

import dominio.*;

public class TestUtente 
{
	private UtenteStandard u;
	private ProfiloUtente p;
	byte[] stream;
	Blob immagine;
	List<Animale>as;
	List<UtenteStandard>followers;
	List<UtenteStandard>followed;
	@Before
	public void setup() throws SQLException
	{
		stream=new byte[7];
		immagine = new SerialBlob(stream);
		as=new ArrayList<Animale>();
		followers=new ArrayList<UtenteStandard>();
		followed=new ArrayList<UtenteStandard>();
		p=new ProfiloUtente("gianni","ilPiùCantato",immagine,"Morandi","3420476687",as);
		u=new UtenteStandard("gianni67",p,false,followers,followed);
	}
	
	@Test
	public void TestGetterUtenteStandard()
	{
		assertEquals(u.getProfilo(),p);
		assertEquals(u.getUsername(),"gianni67");
		assertFalse(u.isBloccato());
		assertEquals(u.getFollowers(),followers);
		assertEquals(u.getFollowed(),followed);
		
	}
	
	@Test
	public void TestSetterUtenteStandard()
	{
		u=new UtenteStandard();
		ProfiloUtente profilo =new ProfiloUtente("gianni","ilPiùCantato",immagine,"Morandi","3420476687",as);
		u.setProfilo(profilo);
		assertEquals(u.getProfilo(),profilo);
		u.setUsername("gianni");
		assertEquals(u.getUsername(),"gianni");
		u.setBloccato(true);
		assertTrue(u.isBloccato());
		u.setFollowers(followers);
		u.setFollowed(followed);
	}
}
