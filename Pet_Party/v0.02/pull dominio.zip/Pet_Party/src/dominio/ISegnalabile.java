package dominio;

public interface ISegnalabile 
{
	
}
