package testDominio;

import org.junit.*;

import dominio.*;

public class TestUtente 
{
	private UtenteStandard u;
	
	@Before
	public void setup()
	{
		u=new UtenteStandard()
	}

}
