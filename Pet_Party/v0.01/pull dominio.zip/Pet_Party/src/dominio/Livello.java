package dominio;

public enum Livello 
{
	Basso,
	Medio,
	Alto;
}
