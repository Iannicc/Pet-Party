package dominio;

public class PostAnimale extends Post 
{
	public PostAnimale()
	{
		super();
	}
}
