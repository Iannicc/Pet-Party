package dominio;

public enum Motivo 
{
	Spam,
	Nudo,
	Violenza,
	Contrabbando,
	Bullismo,
	Altro;
}
