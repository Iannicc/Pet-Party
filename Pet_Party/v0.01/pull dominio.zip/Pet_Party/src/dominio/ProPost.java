package dominio;

public class ProPost extends Post
{
	
	
	public ProPost()
	{
		super();
	}
}
