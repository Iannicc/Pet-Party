package dominio;

public enum Sesso 
{
	Maschio,
	Femmina;
}
