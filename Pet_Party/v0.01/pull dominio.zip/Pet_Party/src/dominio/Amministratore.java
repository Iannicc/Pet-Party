package dominio;

public class Amministratore extends Assistente 
{
	
}
