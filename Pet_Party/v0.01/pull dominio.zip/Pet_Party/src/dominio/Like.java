package dominio;

public class Like 
{
	private String usernameUtente;

	public String getUsernameUtente() {
		return usernameUtente;
	}

	public void setUsernameUtente(String usernameUtente) {
		this.usernameUtente = usernameUtente;
	}

	public Like() {
		super();
	}
	
	
	
}
