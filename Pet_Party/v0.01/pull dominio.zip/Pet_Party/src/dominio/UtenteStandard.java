package dominio;

public class UtenteStandard extends Account 
{
	private ProfiloUtente profilo;
	private boolean bloccato;
	public ProfiloUtente getProfilo() {
		return profilo;
	}
	public void setProfilo(ProfiloUtente profilo) {
		this.profilo = profilo;
	}
	
	public UtenteStandard() {
		super();
		bloccato=false;
	}
	public boolean isBloccato() {
		return bloccato;
	}
	public void setBloccato(boolean bloccato) {
		this.bloccato = bloccato;
	}
	
	
	
	
	
}
