package dominio;

import java.util.ArrayList;
import java.util.List;

public class ProfiloUtente extends Profilo 
{
	private String Cognome;
	private String zona;
	private String telefono;
	private List<Animale> animali=new ArrayList<Animale>();
	private List<UtenteStandard> followers= new ArrayList<UtenteStandard>();
	private List<UtenteStandard> followed= new ArrayList<UtenteStandard>();
	
	
	
	public List<Animale> getAnimali() {
		return animali;
	}
	public void setAnimali(List<Animale> animali) {
		this.animali = animali;
	}
	public String getCognome() {
		return Cognome;
	}
	public void setCognome(String cognome) {
		Cognome = cognome;
	}
	public String getZona() {
		return zona;
	}
	public void setZona(String zona) {
		this.zona = zona;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public ProfiloUtente() {
		super();
	}
	public List<UtenteStandard> getFollowers() {
		return followers;
	}
	public void setFollowers(List<UtenteStandard> followers) {
		this.followers = followers;
	}
	public List<UtenteStandard> getFollowed() {
		return followed;
	}
	public void setFollowed(List<UtenteStandard> followed) {
		this.followed = followed;
	}
	
	public boolean addFollower(UtenteStandard u)
	{
		return this.followers.add(u);
	}
	
	public boolean removeFollower(UtenteStandard u)
	{
		return this.followers.remove(u);
	}
	
	public boolean addFollowed(UtenteStandard u)
	{
		return this.followed.add(u);
	}
	
	public boolean removeFollowed(UtenteStandard u)
	{
		return this.followed.remove(u);
	}
	
}
